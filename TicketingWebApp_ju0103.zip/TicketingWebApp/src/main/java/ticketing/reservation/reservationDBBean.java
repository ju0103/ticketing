package ticketing.reservation;

public class reservationDBBean {

}
