package ticketing.notice;

import java.sql.Timestamp;

public class noticeBean {
	private int n_code;
	private String n_title;
	private String userID;
	private Timestamp n_date;
	private String n_content;
	private int n_available;
	
	
	public int getN_code() {
		return n_code;
	}
	public void setN_code(int n_code) {
		this.n_code = n_code;
	}
	public String getN_title() {
		return n_title;
	}
	public void setN_title(String n_title) {
		this.n_title = n_title;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	public Timestamp getN_date() {
		return n_date;
	}
	public void setN_date(Timestamp n_date) {
		this.n_date = n_date;
	}
	public String getN_content() {
		return n_content;
	}
	public void setN_content(String n_content) {
		this.n_content = n_content;
	}
	public int getN_available() {
		return n_available;
	}
	public void setN_available(int n_available) {
		this.n_available = n_available;
	}
}
