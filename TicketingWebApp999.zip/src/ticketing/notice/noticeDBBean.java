package ticketing.notice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.jsp.tagext.TryCatchFinally;
import javax.sql.DataSource;

import ticketing.manager.ManagerDBBean;

public class noticeDBBean {	
	private static noticeDBBean instance = new noticeDBBean();
	
	public static noticeDBBean getInstance() {
		return instance;
	}
	
	private Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	public String getDate() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String SQL = "SELECT NOW()";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ""; //�����ͺ��̽� ����
	}
	public int getNext() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String SQL = "SELECT n_code FROM NOTICE ORDER BY n_code DESC";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1)+1;
			}
			return 1; //ù��° �Խù��� ���
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //�����ͺ��̽� ����
	}
	
	public int write(String n_title, String uid, String n_content, Timestamp regdate) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		String SQL = "INSERT INTO NOTICE VALUES (?, ?, ?, ?, ?, ?)";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			System.out.println("@@@###getnext" + getNext());
			pstmt.setString(2, n_title);
			pstmt.setString(3, uid);
			pstmt.setTimestamp(4, regdate);
			pstmt.setString(5, n_content);
			pstmt.setInt(6, 1);
			return pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //�����ͺ��̽� ����
	}
	
	public ArrayList<noticeBean> getList(int pageNum){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String SQL = "SELECT * FROM NOTICE WHERE n_code < ? AND n_available = 1 ORDER BY n_code DESC LIMIT 10";
		ArrayList<noticeBean> list = new ArrayList<noticeBean>();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNum - 1) * 10);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				noticeBean nBean = new noticeBean();
				nBean.setN_code(rs.getInt(1));
				nBean.setN_title(rs.getString(2));
				nBean.setUserID(rs.getString(3));
				nBean.setN_date(new Timestamp(System.currentTimeMillis()));
				nBean.setN_content(rs.getString(5));
				nBean.setN_available(rs.getInt(6));
				list.add(nBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list; 
	}
	
	public boolean nextPage(int pageNum) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String SQL = "SELECT * FROM NOTICE WHERE n_code < ? AND n_available = 1";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNum - 1) * 10);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	// notice_View.jsp �Լ�
	public noticeBean getNoticeBean(int n_code) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String SQL = "SELECT * FROM NOTICE WHERE n_code = ?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, n_code);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				noticeBean nBean = new noticeBean();
				nBean.setN_code(rs.getInt(1));
				nBean.setN_title(rs.getString(2));
				nBean.setUserID(rs.getString(3));
				nBean.setN_date(rs.getString(4));
				nBean.setN_content(rs.getString(5));
				nBean.setN_available(rs.getInt(6));
				return nBean;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public int delete(String manager_id,  int n_code){
		Connection conn=null;
		ResultSet rs=null;
		
		String SQL = "UPDATE NOTICE SET N_AVAILABLE = 0 WHERE N_CODE = ?";
		try {
			conn = getConnection();
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, n_code);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	public int update(int n_code, String n_title, String n_content) {
		Connection conn=null;
		ResultSet rs=null;
		
		String SQL = "UPDATE NOTICE SET n_title=?, n_content=? WHERE n_code=?";
		try {
			conn = getConnection();
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, n_title);
			pstmt.setString(2, n_content);
			pstmt.setInt(3, n_code);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
}

